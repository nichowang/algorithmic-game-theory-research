import numpy as np
import matplotlib.pyplot as plt
from tqdm import tqdm

def arithmetic_mean_impartial_rule(R):

    n = R.shape[0]
    shares = np.zeros(n)

    for j in range(n):
 
        evaluations = [R[i, j] for i in range(n) if i != j]
        shares[j] = np.mean(evaluations)


    return shares / shares.sum()


def impartial_rule_experiment(n_min=4, n_max=100, epsilon=0.0005):

    n_values = range(n_min, n_max + 1)
    max_differences = []

    for n in tqdm(n_values, desc="Running experiment"):

        R_initial = np.ones((n, n)) / (n - 1)
        np.fill_diagonal(R_initial, 0) 
        shares_initial = arithmetic_mean_impartial_rule(R_initial)

        R_manipulated = R_initial.copy()
        manipulator_row = np.full(n, epsilon)
        manipulator_row[0] = 0  
        manipulator_row[1] = 1 - (n - 2) * epsilon  

        R_manipulated[0] = manipulator_row

        shares_manipulated = arithmetic_mean_impartial_rule(R_manipulated)


        differences = np.abs(shares_manipulated[1:] - shares_initial[1:])
        max_diff = np.max(differences)

        max_differences.append(max_diff)

    return np.array(list(n_values)), np.array(max_differences)


def plot_results(n_values, max_differences, epsilon=0.0005):
    """Plot the results of the experiment."""
    plt.figure(figsize=(10, 6))
    plt.plot(n_values, max_differences, linewidth=2, marker='o', markersize=3)
    plt.xlabel('Number of agents (n)', fontsize=12)
    plt.ylabel('Maximum difference in shares', fontsize=12)
    plt.title(f'Impact of Manipulation on Arithmetic Mean Impartial Rule\n(epsilon={epsilon})',
              fontsize=14)
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig('impartial_rule_experiment.pdf')
    plt.show()


if __name__ == "__main__":
    epsilon = 0.0005
    n_min = 4
    n_max = 1000

    print(f"Running impartial rule experiment from n={n_min} to n={n_max}...")
    n_values, max_differences = impartial_rule_experiment(n_min, n_max, epsilon)

    print(f"\nResults:")
    print(f"n={n_min}: max_diff = {max_differences[0]:.6f}")
    print(f"n={n_max}: max_diff = {max_differences[-1]:.6f}")
    print(f"Overall trend: {'Decreasing' if max_differences[0] > max_differences[-1] else 'Increasing'}")

    plot_results(n_values, max_differences, epsilon)