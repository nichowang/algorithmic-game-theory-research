"""
CG-CEA for E = 5, 10, 15
Generates CSV files with ratios and PDF figures
"""
import pandas as pd
import matplotlib.pyplot as plt
import subprocess
import sys

# E values to run
E_VALUES = [5, 10, 15]

print("=" * 80)
print("Running CG-CEA for E = 5, 10, 15")
print("=" * 80)

# Import the optimized CEA module
sys.path.insert(0, r"D:\Rochester\CS\Summer RA\Graph learning\Can one embedding fit all")
from CEAfullnew1 import sweep_unique_combinations_with_progress

all_results = []

for E in E_VALUES:
    print(f"\n{'='*60}")
    print(f"Processing E = {E}")
    print(f"{'='*60}\n")

    # Run the sweep
    df = sweep_unique_combinations_with_progress(E=E, D=100, alpha=0.01, manip_index=0)

    # Calculate ratios
    df['restricted_ratio'] = df['restricted_avg'] / df['original_avg']
    df['unrestricted_ratio'] = df['unrestricted_avg'] / df['original_avg']
    df['E'] = E

    # Save individual CSV
    csv_filename = f"cg_cea_results_E{E}.csv"
    df.to_csv(csv_filename, index=False)
    print(f"\n Saved: {csv_filename}")

    all_results.append(df)

# Combine all results
combined_df = pd.concat(all_results, ignore_index=True)
combined_csv = "cg_cea_results_E5_10_15_combined.csv"
combined_df.to_csv(combined_csv, index=False)
print(f"\n Saved combined: {combined_csv}")

# Create figures for each E value
print("\n" + "="*60)
print("Generating PDF figures...")
print("="*60)

for E in E_VALUES:
    df_e = combined_df[combined_df['E'] == E]

    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    # Left: Ratios
    axes[0].plot(df_e["a0"], df_e["restricted_ratio"], label="Restricted/Original",
                linewidth=2, color='#ff7f0e')
    axes[0].plot(df_e["a0"], df_e["unrestricted_ratio"], label="Unrestricted/Original",
                linewidth=2, color='#2ca02c')
    axes[0].axhline(y=1.0, color='gray', linestyle='--', linewidth=1, alpha=0.7, label='Ratio = 1')
    axes[0].set_xlabel("Manipulator initial claim a0", fontsize=11)
    axes[0].set_ylabel("Ratio to Original", fontsize=11)
    axes[0].set_title(f"CG-CEA Manipulation Ratios (E={E}, D=100, n=4)", fontsize=12)
    axes[0].grid(True, alpha=0.3)
    axes[0].legend(fontsize=10)

    # Right: Absolute values
    axes[1].plot(df_e["a0"], df_e["original_avg"], label="Original",
                linewidth=2, color='#1f77b4')
    axes[1].plot(df_e["a0"], df_e["restricted_avg"], label="Restricted",
                linewidth=2, color='#ff7f0e')
    axes[1].plot(df_e["a0"], df_e["unrestricted_avg"], label="Unrestricted",
                linewidth=2, color='#2ca02c')
    axes[1].set_xlabel("Manipulator initial claim a0", fontsize=11)
    axes[1].set_ylabel("Final reward of manipulator", fontsize=11)
    axes[1].set_title(f"CG-CEA Rewards (E={E}, D=100, n=4)", fontsize=12)
    axes[1].grid(True, alpha=0.3)
    axes[1].legend(fontsize=10)

    plt.tight_layout()
    pdf_filename = f"cg_cea_E{E}_figures.pdf"
    plt.savefig(pdf_filename, dpi=300, bbox_inches='tight')
    print(f" Saved: {pdf_filename}")
    plt.close()

print("\n" + "="*80)
print(" All CG-CEA runs complete for E = 5, 10, 15!")
print("="*80)
